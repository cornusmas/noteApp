package com.task.noteapp.database

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import junit.framework.TestCase
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Before

import org.junit.Test
import org.junit.runner.RunWith
import java.text.SimpleDateFormat
import java.util.*

@RunWith(AndroidJUnit4::class)
class NoteDatabaseTest : TestCase() {

    private lateinit var database : NoteDatabase
    private lateinit var dao : NoteDao

    @Before
    public override fun setUp() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        database = Room.inMemoryDatabaseBuilder(context, NoteDatabase::class.java).build()
        dao = database.getNotesDao()
    }

    @After
    fun closeDatabase(){
        database.close()
    }

    @Test
    fun writeAndReadNote() = runBlocking{
        val note = com.task.noteapp.model.Note(
            "Test Title", "Test Image Url", "Test Description",
            SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date()),
            false)
        dao.insert(note)
        val notes = dao.getAllNotes().value
        if (notes != null) {
            assertTrue(notes.contains(note))
        }
    }

}