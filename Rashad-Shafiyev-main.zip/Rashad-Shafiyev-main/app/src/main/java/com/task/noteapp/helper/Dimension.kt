package com.task.noteapp.helper

import android.content.Context
import android.content.res.Resources

class Dimension {
    companion object {
        fun screenWidthPixel() : Int{
            return Resources.getSystem().displayMetrics.widthPixels
        }

        fun pxFromDp(context: Context, dp: Float) : Int{
            return (dp * context.resources.displayMetrics.density).toInt()
        }

    }


}