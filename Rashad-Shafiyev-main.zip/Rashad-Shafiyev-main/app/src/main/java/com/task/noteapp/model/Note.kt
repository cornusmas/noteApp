package com.task.noteapp.model

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "noteTable")

class Note(
    @ColumnInfo(name = "title")
    val title:String,

    @ColumnInfo(name = "imageUrl")
    val imageUrl:String,

    @ColumnInfo(name = "description")
    val description:String,

    @ColumnInfo(name = "createdDate")
    val createdDate: String?,

    @ColumnInfo(name = "edited")
    val edited:Boolean?) {

    @PrimaryKey(autoGenerate = true) var id = 0
}