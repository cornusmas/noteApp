package com.task.noteapp.view

import android.content.Context
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.task.noteapp.databinding.ActivityMainBinding
import com.task.noteapp.model.Note
import com.task.noteapp.view.adapter.ListAdapter
import com.task.noteapp.view.dialog.NoteDeleDialog
import com.task.noteapp.view.dialog.NoteEditDialog
import com.task.noteapp.viewmodel.NoteViewModel

class NoteActivity : AppCompatActivity(), NoteClickListener {

    private lateinit var viewModel: NoteViewModel
    private lateinit var bind: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        bind = ActivityMainBinding.inflate(layoutInflater)
        setContentView(bind.root)

        viewModel = ViewModelProvider(
            this, ViewModelProvider.AndroidViewModelFactory.getInstance(application)
        )[NoteViewModel::class.java]

        val adapter = ListAdapter(this)
        bind.rvNotes.adapter = adapter

        viewModel.allNotes.observe(this) { list ->
            list?.let {
                bind.hasNote = list.isNotEmpty()
                bind.rvNotes.removeAllViews()
                adapter.updateList(list)
            }
        }
    }

    fun onAddClick(view: View) {
        NoteEditDialog(view.context, viewModel, null)
    }

    override fun onEditClick(ctx: Context, note: Note) {
        NoteEditDialog(ctx, viewModel, note)
    }

    override fun onDeleteClick(note: Note) {
        NoteDeleDialog(viewModel, note).show(supportFragmentManager, NoteDeleDialog.TAG)
    }

}