package com.task.noteapp.view

import android.content.Context
import com.task.noteapp.model.Note

interface NoteClickListener {

    fun onEditClick(ctx: Context, note: Note)

    fun onDeleteClick(note: Note)

}