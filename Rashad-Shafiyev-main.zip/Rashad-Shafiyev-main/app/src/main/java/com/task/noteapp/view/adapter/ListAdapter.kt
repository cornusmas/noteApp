package com.task.noteapp.view.adapter

import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.AnimationUtils
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.squareup.picasso.Picasso
import com.task.noteapp.R
import com.task.noteapp.databinding.ItemNoteBinding
import com.task.noteapp.helper.Dimension
import com.task.noteapp.model.Note
import com.task.noteapp.view.NoteClickListener
import com.task.noteapp.view.dialog.NoteOpenDialog

class ListAdapter(
    private val noteClickListener: NoteClickListener
) : RecyclerView.Adapter<ListAdapter.ItemHolder>() {

    private val notes = ArrayList<Note>()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemHolder {
        val bind : ItemNoteBinding = DataBindingUtil.inflate(
            LayoutInflater.from(parent.context), R.layout.item_note, parent, false)
        val view = bind.root
        return ItemHolder(view, bind)
    }

    override fun onBindViewHolder(holder: ItemHolder, position: Int) {
        val note = notes[position]
        val imageUrl = note.imageUrl
        holder.itemBind.note = note
        if (imageUrl.trim().isNotEmpty()) Picasso.get().load(imageUrl).into(holder.itemBind.sivNoteImage)

        val ctx = holder.itemBind.root.context
        val fromEnd = AnimationUtils.loadAnimation(ctx, R.anim.anim_from_end)
        val screenWidth = Dimension.screenWidthPixel()
        val note1Params = holder.itemBind.clNoteForeground1.layoutParams
        note1Params.width = screenWidth-Dimension.pxFromDp(ctx, 32F)
        holder.itemBind.clNoteForeground1.layoutParams = note1Params

        Handler(Looper.getMainLooper()).postDelayed({
            holder.itemView.visibility = View.VISIBLE
            holder.itemView.startAnimation(fromEnd)

            if (position == 0){

                Handler(Looper.getMainLooper()).postDelayed({
                    holder.itemBind.hsvNote.smoothScrollTo(holder.itemBind.hsvNote.width, 0)
                    Handler(Looper.getMainLooper()).postDelayed({
                        holder.itemBind.hsvNote.smoothScrollTo(0, 0)
                    }, 800)
                }, 600)
            }
        }, 300)

        holder.itemBind.clNoteForeground1.setOnClickListener {
            NoteOpenDialog(ctx, note)
        }

        holder.itemBind.bEditNoteForeground.setOnClickListener {
            noteClickListener.onEditClick(ctx, note)
        }
        holder.itemBind.bDeleteForeground.setOnClickListener{
            noteClickListener.onDeleteClick(note)
        }

    }

    override fun getItemCount(): Int {
        return notes.size
    }

    fun updateList(newList: List<Note>) {
        notes.clear()
        notes.addAll(newList)
    }

    class ItemHolder(itemView: View, var itemBind: ItemNoteBinding) : RecyclerView.ViewHolder(itemView){
        init {
            itemView.visibility = View.GONE
        }
    }

}