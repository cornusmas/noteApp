package com.task.noteapp.view.dialog

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.task.noteapp.R
import com.task.noteapp.databinding.LayoutNoteDeleteBinding
import com.task.noteapp.model.Note
import com.task.noteapp.viewmodel.NoteViewModel

class NoteDeleDialog(private var viewModel: NoteViewModel, var note: Note) : BottomSheetDialogFragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val bind : LayoutNoteDeleteBinding = DataBindingUtil.inflate(
            inflater, R.layout.layout_note_delete, container, false)
        bind.bNo.setOnClickListener {
            dismiss()
        }
        bind.bYes.setOnClickListener {
            viewModel.deleteNote(note)
            dismiss()
        }
        return bind.root
    }

    companion object {
        const val TAG = "NoteDeleDialog"
    }

}