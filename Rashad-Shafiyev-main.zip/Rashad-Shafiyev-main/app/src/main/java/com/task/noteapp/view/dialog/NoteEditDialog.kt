package com.task.noteapp.view.dialog

import android.app.Dialog
import android.content.Context
import android.view.LayoutInflater
import androidx.databinding.DataBindingUtil
import com.task.noteapp.R
import com.task.noteapp.databinding.LayoutNoteEditBinding
import com.task.noteapp.model.Note
import com.task.noteapp.viewmodel.NoteViewModel

class NoteEditDialog(ctx: Context, viewModel: NoteViewModel, note: Note?) : Dialog(ctx){

    private val bindNoteOpen: LayoutNoteEditBinding = DataBindingUtil.inflate(
        LayoutInflater.from(ctx), R.layout.layout_note_edit, null, false)
    private val dNoteOpen = Dialog(ctx)

    init {
        dNoteOpen.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dNoteOpen.setContentView(bindNoteOpen.root)
        dNoteOpen.show()
        if (note!=null) bindNoteOpen.note = note
        bindNoteOpen.bSaveNote.setOnClickListener {
            dNoteOpen.dismiss()

            if (note==null) viewModel.addNote(bindNoteOpen)

            else viewModel.updateNote(bindNoteOpen, note)
        }
    }

}