package com.task.noteapp.view.dialog

import android.app.Dialog
import android.content.Context
import android.view.LayoutInflater
import androidx.databinding.DataBindingUtil
import com.squareup.picasso.Picasso
import com.task.noteapp.R
import com.task.noteapp.databinding.LayoutNoteOpenBinding
import com.task.noteapp.model.Note

class NoteOpenDialog(ctx: Context, note: Note) : Dialog(ctx){

    private val bindNoteOpen: LayoutNoteOpenBinding = DataBindingUtil.inflate(
        LayoutInflater.from(ctx), R.layout.layout_note_open, null, false)
    private val dNoteOpen = Dialog(ctx)
    val imageUrl = note.imageUrl

    init {
        if (imageUrl.trim().isNotEmpty()) Picasso.get().load(imageUrl).into(bindNoteOpen.sivNoteImage)
        bindNoteOpen.note = note

        dNoteOpen.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dNoteOpen.setContentView(bindNoteOpen.root)
        dNoteOpen.show()
    }

}