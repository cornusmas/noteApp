package com.task.noteapp.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import com.task.noteapp.model.Note
import com.task.noteapp.database.NoteDatabase
import com.task.noteapp.databinding.LayoutNoteEditBinding
import com.task.noteapp.repository.NoteRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class NoteViewModel (application: Application) : AndroidViewModel(application) {

    val allNotes: LiveData<List<Note>>
    private val repository: NoteRepository

    init {
        val dao = NoteDatabase.getDatabase(application).getNotesDao()
        repository = NoteRepository(dao)
        allNotes = repository.allNotes
    }

    fun addNote(bindNoteOpen: LayoutNoteEditBinding) = viewModelScope.launch(Dispatchers.IO) {
        val note = Note(
            bindNoteOpen.etNoteTitle.text.toString(),
            bindNoteOpen.etNoteImageUrl.text.toString(),
            bindNoteOpen.etNoteDescription.text.toString(),
            SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date()),
            false,
        )
        repository.insert(note)
    }

    fun updateNote(bindNoteOpen: LayoutNoteEditBinding, note: Note) = viewModelScope.launch(Dispatchers.IO) {
        val title = bindNoteOpen.etNoteTitle.text.toString()
        val imageUrl = bindNoteOpen.etNoteImageUrl.text.toString()
        val description = bindNoteOpen.etNoteDescription.text.toString()
        val editedNote = Note(title, imageUrl, description, note.createdDate, true)
        editedNote.id = note.id
        if ((title != note.title) || (imageUrl != note.imageUrl) || (description != note.description)){
            repository.update(editedNote)
        }
    }

    fun deleteNote(note: Note) = viewModelScope.launch(Dispatchers.IO) {
        repository.delete(note)
    }

}