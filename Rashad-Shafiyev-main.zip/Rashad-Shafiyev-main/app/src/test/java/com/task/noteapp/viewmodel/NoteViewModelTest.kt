package com.task.noteapp.viewmodel

import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Test

internal class NoteViewModelTest {
    
    @After
    @org.junit.jupiter.api.Test
    fun getAllNotes() {

    }

    @org.junit.jupiter.api.Test
    fun addNote() {

    }

    @org.junit.jupiter.api.Test
    fun updateNote() {
    }

    @org.junit.jupiter.api.Test
    fun deleteNote() {

    }

    @Test
    fun test() = runBlocking {

    }
}